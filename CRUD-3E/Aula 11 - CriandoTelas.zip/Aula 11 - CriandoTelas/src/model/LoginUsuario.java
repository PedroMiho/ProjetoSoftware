package model;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class LoginUsuario {
	
	//Criar um método que retornará o objeto Usuário ou null
	
	public Usuario verificarLogin(String login, String senha) throws SQLException {
		
		//SQL para buscar o usuário 
		String sql = "SELECT * FROM usuarios WHERE login = ?";
		
		try (Connection conn = ConexaoDB.conectar();
			PreparedStatement stmt = conn.prepareStatement(sql)){
			
			stmt.setString(1, login);
			ResultSet rs = stmt.executeQuery();
			
			//Validar se a consulta retornou Null
			if (!rs.next()) {
				return null;
			}
			
		
			
			
		}

		
	}
	
}


